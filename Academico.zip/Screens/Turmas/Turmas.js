import React from 'react'
import { Text } from 'react-native-paper'

const Turmas = ({navigation}) => {
  return (
    <Text style={{ color: 'black' }}>Turmas</Text>
  )
}

export default Turmas